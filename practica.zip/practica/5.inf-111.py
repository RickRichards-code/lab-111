'''5. Dados dos números enteros positivos, determinar si uno es múltiplo
del otro.'''
a, b = map(int, input("ingrese do numeros: ").split())
if a<b and a%b==0:
    print()
