'''3. Dados dos números enteros positivos intercambiar sus valores sin
utilizar estructuras condicionales'''
